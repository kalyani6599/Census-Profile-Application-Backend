package com.capgemini.census.Censusprofileapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CensusProfileApplicationTests {

	
	@Test
	void contextLoads() {
	}

	
}
