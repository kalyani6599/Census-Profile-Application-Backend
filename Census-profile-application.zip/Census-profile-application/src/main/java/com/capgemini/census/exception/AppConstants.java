package com.capgemini.census.exception;
public class AppConstants {
    //Error Messages
        public static final String USER_NOT_FOUND = "User not found for this id ";
        public static final String WRONG_PASSWORD = "Enter valid password ";
        public static final String OPERATION_FAILED = "Something went wrong ";
}