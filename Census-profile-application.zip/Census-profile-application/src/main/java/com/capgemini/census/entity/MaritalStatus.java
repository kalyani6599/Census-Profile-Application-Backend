package com.capgemini.census.entity;
/**
 * Enum for MaritalStatus
 * @author HP
 *
 */
public enum MaritalStatus {
	MARRIED,UNMARRIED;

}
