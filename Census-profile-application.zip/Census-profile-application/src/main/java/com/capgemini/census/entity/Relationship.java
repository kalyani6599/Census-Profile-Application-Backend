package com.capgemini.census.entity;
/**
 * Enum for Relationship 
 * @author HP
 *
 */
public enum Relationship {
	MOTHER,FATHER,SON,DAUGHTER;

}
