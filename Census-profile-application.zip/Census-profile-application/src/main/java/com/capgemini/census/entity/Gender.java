package com.capgemini.census.entity;

public enum Gender {
	MALE,FEMALE,OTHER;

}
