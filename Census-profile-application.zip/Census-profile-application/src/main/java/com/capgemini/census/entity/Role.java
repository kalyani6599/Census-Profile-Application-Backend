package com.capgemini.census.entity;
/**
 * Enum for Role
 * @author HP
 *
 */
public enum Role {

	ADMIN,USER;
}
